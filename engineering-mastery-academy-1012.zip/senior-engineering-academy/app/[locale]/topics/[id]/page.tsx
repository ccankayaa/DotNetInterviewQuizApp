import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, ArrowRight, BookOpen, CheckCircle2, ExternalLink, Lightbulb, Scale, Search, ShieldAlert } from 'lucide-react';
import { getTopic, getCategory, relatedQuestions, topics, type Locale } from '@/lib/content';
import { copy } from '@/lib/copy';
import { absolute, path } from '@/lib/routes';
import { Chip, Difficulty } from '@/components/ui-helpers';
import { getDeepDive } from '@/lib/deep-dives';
const blocks = [{ field: 'mechanism' as const, key: 'lessonMechanism' as const, icon: BookOpen }, { field: 'practice' as const, key: 'lessonPractice' as const, icon: CheckCircle2 }, { field: 'pitfall' as const, key: 'lessonPitfall' as const, icon: ShieldAlert }, { field: 'tradeoff' as const, key: 'lessonTradeoff' as const, icon: Scale }, { field: 'signal' as const, key: 'lessonSignal' as const, icon: Search }];
export async function generateStaticParams() { return topics.map(t => ({ id: t.id })); }
export async function generateMetadata({ params }: { params: Promise<{ locale: Locale; id: string }> }): Promise<Metadata> {  
const { locale, id } = await params; const t = getTopic(id); if (!t) return {};
  return { title: t.title[locale], description: t.facts.mechanism[locale], alternates: { canonical: absolute(locale, `/topics/${id}`), languages: { en: absolute('en', `/topics/${id}`), tr: absolute('tr', `/topics/${id}`) } } };
}
export default async function TopicDetail({ params }: { params: Promise<{ locale: Locale; id: string }> }) {
  const { locale, id } = await params; const topic = getTopic(id); if (!topic) notFound(); const cat = getCategory(topic.category); const related = relatedQuestions(id); const dive = getDeepDive(id);
  return <article className="lesson-page"><div className="breadcrumbs"><Link href={path(locale, '/topics')}><ArrowLeft size={16} />{copy(locale, 'navTopics')}</Link><span>/</span><span>{cat?.title[locale]}</span></div>
    <header className="lesson-hero"><div className="lesson-tags"><Chip tone="accent">{cat?.title[locale]}</Chip><Difficulty locale={locale} level={topic.level} /><Chip>{related.length} {copy(locale, 'statQuestions')}</Chip></div>
      <h1>{topic.title[locale]}</h1><p>{topic.facts.mechanism[locale]}</p><div className="lesson-top-links"><Link href={path(locale, `/questions?topic=${topic.id}`)} className="btn btn-primary">{copy(locale, 'seeQuestions')} <ArrowRight size={17} /></Link><a href={topic.source} target="_blank" rel="noreferrer" className="btn btn-outline">{copy(locale, 'readSource')} <ExternalLink size={15} /></a></div>
    </header><div className="lesson-layout"><div className="lesson-body"><div className="eyebrow">{locale === 'tr' ? 'TEKNİK DERİNLEŞME' : 'TECHNICAL DEEP DIVE'}</div>
      {blocks.map((b, i) => { const Icon = b.icon; return <section className="lesson-section" id={b.field} key={b.field}><div className="lesson-section-number">{String(i + 1).padStart(2, '0')}</div><div><div className="lesson-section-top"><Icon size={21} /><h2>{copy(locale, b.key)}</h2></div><p>{topic.facts[b.field][locale]}</p></div></section>; })}
      {dive && <section className="deep-lab"><div className="eyebrow">{locale === 'tr' ? 'MÜHENDİSLİK NOTLARI' : 'ENGINEERING FIELD NOTES'}</div><h2>{locale === 'tr' ? 'Pratik zihinsel model ve kod örneği' : 'Mental model & practical code example'}</h2><p>{dive.mentalModel[locale]}</p><div className="code-caption">{locale === 'tr' ? 'Örnek / öğretici sözde kod olabilir' : 'Illustration / may contain pseudocode'} · {dive.language}</div><pre className="guide-code"><code>{dive.code}</code></pre><p><strong>{locale === 'tr' ? 'Mülakatta bunu açıklayabil:' : 'Interview checkpoint:'} </strong>{dive.checkpoint[locale]}</p></section>}
      <div className="lesson-memory"><Lightbulb size={23} /><div><strong>{copy(locale, 'memory')}</strong><p>{copy(locale, 'lessonReminder')}</p></div></div>
      <section className="lesson-related"><div className="eyebrow">{locale === 'tr' ? 'ÖĞRENME KONTROLÜ' : 'PRACTICE CHECKPOINT'}</div><h2>{copy(locale, 'seeQuestions')}</h2><div className="related-list">{related.map((q, i) => <Link href={path(locale, `/questions/${q.id}`)} key={q.id}><span>{String(i + 1).padStart(2, '0')}</span><div><strong>{q.title[locale]}</strong><small>{q.prompt[locale]}</small></div><ArrowRight size={18} /></Link>)}</div></section>
    </div><aside className="lesson-aside"><div className="sticky-aside"><span className="eyebrow">{locale === 'tr' ? 'KONU HARİTASI' : 'LESSON MAP'}</span><ol>{blocks.map((b, i) => <li key={b.field}><a href={'#' + b.field}><span>{i + 1}.</span>{copy(locale, b.key)}</a></li>)}</ol><div className="aside-source"><span>{copy(locale, 'source')}</span><a target="_blank" rel="noreferrer" href={topic.source}>{new URL(topic.source).hostname}<ExternalLink size={14} /></a></div></div></aside></div>
  </article>;
}
